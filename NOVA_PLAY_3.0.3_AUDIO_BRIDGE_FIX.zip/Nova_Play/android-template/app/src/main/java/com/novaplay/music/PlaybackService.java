package com.novaplay.music;

import android.content.Intent;
import androidx.annotation.Nullable;
import androidx.media3.common.Player;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

public class PlaybackService extends MediaSessionService {
    @Override
    public void onCreate() {
        super.onCreate();
        PlayerHolder.init(this);
        addSession(PlayerHolder.session);
    }

    @Nullable
    @Override
    public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        PlayerHolder.init(this);
        return PlayerHolder.session;
    }

    @Override
    public void onTaskRemoved(@Nullable Intent rootIntent) {
        Player p = PlayerHolder.player;
        if (p == null || !p.getPlayWhenReady() || p.getMediaItemCount() == 0) stopSelf();
    }
}

package com.novaplay.music;

import android.content.Context;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;

final class PlayerHolder {
    static ExoPlayer player;
    static MediaSession session;

    // Must be called on the main thread.
    static synchronized void init(Context context) {
        if (player != null) return;
        Context app = context.getApplicationContext();
        player = new ExoPlayer.Builder(app)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(), true)
            .build();
        session = new MediaSession.Builder(app, player).build();
    }
}

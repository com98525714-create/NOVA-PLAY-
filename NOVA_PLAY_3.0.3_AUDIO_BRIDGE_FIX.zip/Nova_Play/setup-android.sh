#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "ERROR: Node.js is required"; exit 1; }
command -v npm >/dev/null || { echo "ERROR: npm is required"; exit 1; }
command -v python3 >/dev/null || { echo "ERROR: python3 is required"; exit 1; }
npm install
if [ ! -d android ]; then npx cap add android; fi
JAVA_DIR="android/app/src/main/java/com/novaplay/music"
mkdir -p "$JAVA_DIR"
cp android-template/app/src/main/java/com/novaplay/music/*.java "$JAVA_DIR/"
python3 - <<'PYCODE'
from pathlib import Path
manifest = Path('android/app/src/main/AndroidManifest.xml')
if not manifest.exists(): raise SystemExit('ERROR: AndroidManifest.xml not found')
s = manifest.read_text(encoding='utf-8')
permissions = ['android.permission.READ_MEDIA_AUDIO','android.permission.READ_EXTERNAL_STORAGE','android.permission.FOREGROUND_SERVICE','android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK','android.permission.POST_NOTIFICATIONS','android.permission.WAKE_LOCK']
add=[]
for permission in permissions:
    if permission not in s:
        if permission.endswith('READ_EXTERNAL_STORAGE'):
            add.append(f'    <uses-permission android:name="{permission}" android:maxSdkVersion="32" />')
        else: add.append(f'    <uses-permission android:name="{permission}" />')
if add: s=s.replace('</manifest>','\n'.join(add)+'\n</manifest>')
service="""        <service android:name=".PlaybackService" android:exported="true" android:foregroundServiceType="mediaPlayback">
            <intent-filter><action android:name="androidx.media3.session.MediaSessionService" /></intent-filter>
        </service>"""
if 'android:name=".PlaybackService"' not in s: s=s.replace('</application>',service+'\n    </application>')
manifest.write_text(s,encoding='utf-8')
gradle=Path('android/app/build.gradle')
if not gradle.exists(): raise SystemExit('ERROR: app/build.gradle not found')
g=gradle.read_text(encoding='utf-8')
if 'androidx.media3:media3-exoplayer' not in g:
    block="""dependencies {
    implementation "androidx.media3:media3-exoplayer:1.4.1"
    implementation "androidx.media3:media3-session:1.4.1"
    implementation "androidx.media3:media3-common:1.4.1"
"""
    if 'dependencies {' in g: g=g.replace('dependencies {',block,1)
    else: g += '\n'+block+'}\n'
gradle.write_text(g,encoding='utf-8')
main=Path('android/app/src/main/java/com/novaplay/music/MainActivity.java')
if not main.exists() or 'registerPlugin(AudioLibraryPlugin.class)' not in main.read_text(encoding='utf-8'):
    raise SystemExit('ERROR: AudioLibraryPlugin registration missing')
print('Android native plugin, manifest, Media3 dependencies and service prepared.')
PYCODE
npx cap sync android
echo "Preparation complete. Run: npx cap open android"
echo "Then Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)"

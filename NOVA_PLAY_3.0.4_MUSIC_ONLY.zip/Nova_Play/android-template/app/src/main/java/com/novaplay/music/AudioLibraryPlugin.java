package com.novaplay.music;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

@CapacitorPlugin(
    name = "AudioLibrary",
    permissions = {
        @Permission(alias = "audio33", strings = { Manifest.permission.READ_MEDIA_AUDIO }),
        @Permission(alias = "audioLegacy", strings = { Manifest.permission.READ_EXTERNAL_STORAGE }),
        @Permission(alias = "notif", strings = { Manifest.permission.POST_NOTIFICATIONS })
    }
)
public class AudioLibraryPlugin extends Plugin {

    private ContentObserver audioObserver;

    private String alias() { return Build.VERSION.SDK_INT >= 33 ? "audio33" : "audioLegacy"; }

    private boolean granted() { return getPermissionState(alias()) == PermissionState.GRANTED; }

    @PluginMethod
    public void requestAudioPermission(PluginCall call) {
        if (granted()) {
            JSObject ret = new JSObject(); ret.put("granted", true); call.resolve(ret);
        } else {
            requestPermissionForAlias(alias(), call, "permissionResult");
        }
    }

    @PermissionCallback
    private void permissionResult(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", granted());
        call.resolve(ret);
    }

    @PluginMethod
    public void getAudioFiles(PluginCall call) {
        if (!granted()) { call.reject("Audio permission not granted"); return; }
        JSArray files = new JSArray();
        ContentResolver resolver = getContext().getContentResolver();
        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.MIME_TYPE, MediaStore.Audio.Media.DATE_ADDED
        };
        // Return music tracks only; exclude recordings, notifications and other audio.
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0 AND "
            + MediaStore.Audio.Media.DURATION + " > 0";
        try (Cursor c = resolver.query(collection, projection, selection, null,
                MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (c != null) {
                while (c.moveToNext()) {
                    long id = c.getLong(0);
                    long albumId = c.getLong(5);
                    JSObject item = new JSObject();
                    item.put("id", id);
                    item.put("title", c.getString(1));
                    item.put("displayName", c.getString(2));
                    item.put("artist", c.getString(3));
                    item.put("album", c.getString(4));
                    item.put("duration", c.getLong(6));
                    item.put("mimeType", c.getString(7));
                    item.put("added", c.getLong(8));
                    item.put("uri", ContentUris.withAppendedId(collection, id).toString());
                    item.put("art", ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId).toString());
                    files.put(item);
                }
            }
            JSObject ret = new JSObject();
            ret.put("files", files);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Could not read audio library", e);
        }
    }

    interface Task { void run() throws Exception; }

    private void onMain(PluginCall call, Task t) {
        getActivity().runOnUiThread(() -> {
            try { PlayerHolder.init(getContext()); t.run(); }
            catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
        });
    }

    @Override
    public void load() {
        getActivity().runOnUiThread(() -> {
            PlayerHolder.init(getContext());
            if (audioObserver == null) {
                audioObserver = new ContentObserver(new Handler(Looper.getMainLooper())) {
                    @Override public void onChange(boolean selfChange, Uri uri) {
                        notifyListeners("libraryChanged", new JSObject());
                    }
                };
                getContext().getContentResolver().registerContentObserver(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, audioObserver);
            }
            PlayerHolder.player.addListener(new Player.Listener() {
                @Override public void onMediaItemTransition(MediaItem m, int r) { notifyListeners("state", state()); }
                @Override public void onIsPlayingChanged(boolean p) { notifyListeners("state", state()); }
                @Override public void onPlaybackStateChanged(int s) { notifyListeners("state", state()); }
            });
        });
    }

    private JSObject state() {
        Player p = PlayerHolder.player;
        JSObject o = new JSObject();
        o.put("playing", p.isPlaying());
        o.put("position", p.getCurrentPosition());
        o.put("duration", Math.max(0L, p.getDuration()));
        o.put("index", p.getCurrentMediaItemIndex());
        MediaItem m = p.getCurrentMediaItem();
        String id = m != null ? m.mediaId : null;
        o.put("mediaId", id);
        return o;
    }

    @PluginMethod
    public void requestNotificationPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT < 33 || getPermissionState("notif") == PermissionState.GRANTED) {
            JSObject ret = new JSObject(); ret.put("granted", true); call.resolve(ret);
        } else {
            requestPermissionForAlias("notif", call, "notifResult");
        }
    }

    @PermissionCallback
    private void notifResult(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", getPermissionState("notif") == PermissionState.GRANTED);
        call.resolve(ret);
    }

    @PluginMethod
    public void setQueue(PluginCall call) {
        JSArray items = call.getArray("items");
        int index = call.getInt("index", 0);
        long pos = call.getLong("position", 0L);
        boolean autoPlay = call.getBoolean("play", true);
        onMain(call, () -> {
            List<MediaItem> list = new ArrayList<>();
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.getJSONObject(i);
                MediaMetadata.Builder md = new MediaMetadata.Builder()
                    .setTitle(o.optString("title")).setArtist(o.optString("artist")).setAlbumTitle(o.optString("album"));
                String art = o.optString("art");
                if (!art.isEmpty()) md.setArtworkUri(Uri.parse(art));
                list.add(new MediaItem.Builder().setMediaId(o.getString("id"))
                    .setUri(Uri.parse(o.getString("uri"))).setMediaMetadata(md.build()).build());
            }
            Player p = PlayerHolder.player;
            p.setMediaItems(list, index, pos);
            p.prepare();
            p.setPlayWhenReady(autoPlay);
            getContext().startService(new Intent(getContext(), PlaybackService.class));
            call.resolve();
        });
    }

    @PluginMethod public void play(PluginCall c) { onMain(c, () -> { PlayerHolder.player.play(); c.resolve(); }); }
    @PluginMethod public void pause(PluginCall c) { onMain(c, () -> { PlayerHolder.player.pause(); c.resolve(); }); }
    @PluginMethod public void next(PluginCall c) { onMain(c, () -> { PlayerHolder.player.seekToNextMediaItem(); c.resolve(); }); }
    @PluginMethod public void previous(PluginCall c) { onMain(c, () -> { PlayerHolder.player.seekToPrevious(); c.resolve(); }); }
    @PluginMethod public void getState(PluginCall c) { onMain(c, () -> c.resolve(state())); }

    @PluginMethod
    public void seekTo(PluginCall c) {
        long pos = c.getLong("position", 0L);
        onMain(c, () -> { PlayerHolder.player.seekTo(pos); c.resolve(); });
    }

    @PluginMethod
    public void seekBy(PluginCall c) {
        long d = c.getLong("delta", 0L);
        onMain(c, () -> { Player p = PlayerHolder.player; p.seekTo(Math.max(0L, p.getCurrentPosition() + d)); c.resolve(); });
    }

    @PluginMethod
    public void setRepeat(PluginCall c) {
        int m = c.getInt("mode", 0);
        onMain(c, () -> {
            PlayerHolder.player.setRepeatMode(m == 1 ? Player.REPEAT_MODE_ONE : m == 2 ? Player.REPEAT_MODE_ALL : Player.REPEAT_MODE_OFF);
            c.resolve();
        });
    }

    @PluginMethod
    public void setShuffle(PluginCall c) {
        boolean e = c.getBoolean("enabled", false);
        onMain(c, () -> { PlayerHolder.player.setShuffleModeEnabled(e); c.resolve(); });
    }

    @PluginMethod
    public void setVolume(PluginCall c) {
        float v = c.getFloat("volume", 1f);
        onMain(c, () -> { PlayerHolder.player.setVolume(v); c.resolve(); });
    }
}

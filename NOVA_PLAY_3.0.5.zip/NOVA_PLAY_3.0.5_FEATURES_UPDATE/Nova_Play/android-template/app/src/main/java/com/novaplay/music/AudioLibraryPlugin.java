package com.novaplay.music;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.app.PendingIntent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.audiofx.Equalizer;
import android.util.Base64;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import android.database.Cursor;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

@CapacitorPlugin(
    name = "AudioLibrary",
    permissions = {
        @Permission(alias = "audio33", strings = { Manifest.permission.READ_MEDIA_AUDIO }),
        @Permission(alias = "audioLegacy", strings = { Manifest.permission.READ_EXTERNAL_STORAGE }),
        @Permission(alias = "notif", strings = { Manifest.permission.POST_NOTIFICATIONS })
    }
)
public class AudioLibraryPlugin extends Plugin {

    private ContentObserver audioObserver;
    private ActivityResultLauncher<IntentSenderRequest> deleteLauncher;
    private PluginCall pendingDeleteCall;

    private String alias() { return Build.VERSION.SDK_INT >= 33 ? "audio33" : "audioLegacy"; }

    private boolean granted() { return getPermissionState(alias()) == PermissionState.GRANTED; }

    @PluginMethod
    public void requestAudioPermission(PluginCall call) {
        if (granted()) {
            JSObject ret = new JSObject(); ret.put("granted", true); call.resolve(ret);
        } else {
            requestPermissionForAlias(alias(), call, "permissionResult");
        }
    }

    @PermissionCallback
    private void permissionResult(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", granted());
        call.resolve(ret);
    }

    @PluginMethod
    public void getAudioFiles(PluginCall call) {
        if (!granted()) { call.reject("Audio permission not granted"); return; }
        JSArray files = new JSArray();
        ContentResolver resolver = getContext().getContentResolver();
        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.MIME_TYPE, MediaStore.Audio.Media.DATE_ADDED
        };
        // Return music tracks only; exclude recordings, notifications and other audio.
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0 AND "
            + MediaStore.Audio.Media.DURATION + " > 0";
        try (Cursor c = resolver.query(collection, projection, selection, null,
                MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (c != null) {
                while (c.moveToNext()) {
                    long id = c.getLong(0);
                    long albumId = c.getLong(5);
                    JSObject item = new JSObject();
                    item.put("id", id);
                    item.put("albumId", albumId);
                    item.put("title", c.getString(1));
                    item.put("displayName", c.getString(2));
                    item.put("artist", c.getString(3));
                    item.put("album", c.getString(4));
                    item.put("duration", c.getLong(6));
                    item.put("mimeType", c.getString(7));
                    item.put("added", c.getLong(8));
                    item.put("uri", ContentUris.withAppendedId(collection, id).toString());
                    item.put("art", ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId).toString());
                    files.put(item);
                }
            }
            JSObject ret = new JSObject();
            ret.put("files", files);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Could not read audio library", e);
        }
    }

    interface Task { void run() throws Exception; }

    private void onMain(PluginCall call, Task t) {
        getActivity().runOnUiThread(() -> {
            try { PlayerHolder.init(getContext()); t.run(); }
            catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
        });
    }

    @Override
    public void load() {
        if (deleteLauncher == null) {
            deleteLauncher = bridge.registerForActivityResult(
                new ActivityResultContracts.StartIntentSenderForResult(),
                result -> {
                    PluginCall saved = pendingDeleteCall;
                    pendingDeleteCall = null;
                    if (saved == null) return;
                    JSObject out = new JSObject();
                    boolean ok = result.getResultCode() == android.app.Activity.RESULT_OK;
                    out.put("deleted", ok);
                    saved.resolve(out);
                    bridge.releaseCall(saved);
                }
            );
        }
        getActivity().runOnUiThread(() -> {
            PlayerHolder.init(getContext());
            if (audioObserver == null) {
                audioObserver = new ContentObserver(new Handler(Looper.getMainLooper())) {
                    @Override public void onChange(boolean selfChange, Uri uri) {
                        notifyListeners("libraryChanged", new JSObject());
                    }
                };
                getContext().getContentResolver().registerContentObserver(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, audioObserver);
            }
            PlayerHolder.player.addListener(new Player.Listener() {
                @Override public void onMediaItemTransition(MediaItem m, int r) { notifyListeners("state", state()); }
                @Override public void onIsPlayingChanged(boolean p) { notifyListeners("state", state()); }
                @Override public void onPlaybackStateChanged(int s) { notifyListeners("state", state()); }
            });
        });
    }

    private JSObject state() {
        Player p = PlayerHolder.player;
        JSObject o = new JSObject();
        o.put("playing", p.isPlaying());
        o.put("position", p.getCurrentPosition());
        o.put("duration", Math.max(0L, p.getDuration()));
        o.put("index", p.getCurrentMediaItemIndex());
        MediaItem m = p.getCurrentMediaItem();
        String id = m != null ? m.mediaId : null;
        o.put("mediaId", id);
        return o;
    }

    @PluginMethod
    public void setEqualizer(PluginCall call) {
        float bass = call.getFloat("bass", 0f);
        float mid = call.getFloat("mid", 0f);
        float treble = call.getFloat("treble", 0f);
        onMain(call, () -> {
            int sessionId = PlayerHolder.audioSessionId;
            if (sessionId <= 0) { call.reject("Audio session is unavailable"); return; }
            try {
                if (PlayerHolder.equalizer == null) PlayerHolder.equalizer = new Equalizer(0, sessionId);
                Equalizer eq = PlayerHolder.equalizer;
                short[] range = eq.getBandLevelRange();
                short min = range[0], max = range[1];
                for (short band = 0; band < eq.getNumberOfBands(); band++) {
                    int hz = eq.getCenterFreq(band) / 1000;
                    float gain = hz < 250 ? bass : (hz < 4000 ? mid : treble);
                    short level = (short) Math.max(min, Math.min(max, Math.round(gain * 100f)));
                    eq.setBandLevel(band, level);
                }
                eq.setEnabled(true);
                call.resolve();
            } catch (Exception e) { call.reject("Equalizer is not supported on this device", e); }
        });
    }

    @PluginMethod
    public void getAlbumArt(PluginCall call) {
        long albumId = call.getLong("albumId", -1L);
        if (albumId < 0) { call.reject("Invalid album id"); return; }
        Uri artUri = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId);
        try (java.io.InputStream in = getContext().getContentResolver().openInputStream(artUri)) {
            if (in == null) { call.resolve(new JSObject()); return; }
            Bitmap bitmap = BitmapFactory.decodeStream(in);
            if (bitmap == null) { call.resolve(new JSObject()); return; }
            java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 78, bytes);
            bitmap.recycle();
            JSObject out = new JSObject();
            out.put("dataUrl", "data:image/jpeg;base64," + Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP));
            call.resolve(out);
        } catch (Exception e) { call.resolve(new JSObject()); }
    }

    @PluginMethod
    public void deleteAudio(PluginCall call) {
        if (Build.VERSION.SDK_INT < 30) { call.reject("حذف الملفات يتطلب Android 11 أو أحدث في هذا الإصدار"); return; }
        long id;
        try { id = Long.parseLong(call.getString("id")); }
        catch (Exception e) { call.reject("Invalid audio id"); return; }
        Uri uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
        try {
            PendingIntent request = MediaStore.createDeleteRequest(getContext().getContentResolver(), java.util.Collections.singletonList(uri));
            pendingDeleteCall = call;
            bridge.saveCall(call);
            deleteLauncher.launch(new IntentSenderRequest.Builder(request.getIntentSender()).build());
        } catch (Exception e) { pendingDeleteCall = null; call.reject("تعذر فتح تأكيد الحذف", e); }
    }

    @PluginMethod
    public void requestNotificationPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT < 33 || getPermissionState("notif") == PermissionState.GRANTED) {
            JSObject ret = new JSObject(); ret.put("granted", true); call.resolve(ret);
        } else {
            requestPermissionForAlias("notif", call, "notifResult");
        }
    }

    @PermissionCallback
    private void notifResult(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", getPermissionState("notif") == PermissionState.GRANTED);
        call.resolve(ret);
    }

    @PluginMethod
    public void setQueue(PluginCall call) {
        JSArray items = call.getArray("items");
        int index = call.getInt("index", 0);
        long pos = call.getLong("position", 0L);
        boolean autoPlay = call.getBoolean("play", true);
        onMain(call, () -> {
            List<MediaItem> list = new ArrayList<>();
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.getJSONObject(i);
                MediaMetadata.Builder md = new MediaMetadata.Builder()
                    .setTitle(o.optString("title")).setArtist(o.optString("artist")).setAlbumTitle(o.optString("album"));
                String art = o.optString("art");
                if (!art.isEmpty()) md.setArtworkUri(Uri.parse(art));
                list.add(new MediaItem.Builder().setMediaId(o.getString("id"))
                    .setUri(Uri.parse(o.getString("uri"))).setMediaMetadata(md.build()).build());
            }
            Player p = PlayerHolder.player;
            p.setMediaItems(list, index, pos);
            p.prepare();
            p.setPlayWhenReady(autoPlay);
            getContext().startService(new Intent(getContext(), PlaybackService.class));
            call.resolve();
        });
    }

    @PluginMethod public void play(PluginCall c) { onMain(c, () -> { PlayerHolder.player.play(); c.resolve(); }); }
    @PluginMethod public void pause(PluginCall c) { onMain(c, () -> { PlayerHolder.player.pause(); c.resolve(); }); }
    @PluginMethod public void next(PluginCall c) { onMain(c, () -> { PlayerHolder.player.seekToNextMediaItem(); c.resolve(); }); }
    @PluginMethod public void previous(PluginCall c) { onMain(c, () -> { PlayerHolder.player.seekToPrevious(); c.resolve(); }); }
    @PluginMethod public void getState(PluginCall c) { onMain(c, () -> c.resolve(state())); }

    @PluginMethod
    public void seekTo(PluginCall c) {
        long pos = c.getLong("position", 0L);
        onMain(c, () -> { PlayerHolder.player.seekTo(pos); c.resolve(); });
    }

    @PluginMethod
    public void seekBy(PluginCall c) {
        long d = c.getLong("delta", 0L);
        onMain(c, () -> { Player p = PlayerHolder.player; p.seekTo(Math.max(0L, p.getCurrentPosition() + d)); c.resolve(); });
    }

    @PluginMethod
    public void setRepeat(PluginCall c) {
        int m = c.getInt("mode", 0);
        onMain(c, () -> {
            PlayerHolder.player.setRepeatMode(m == 1 ? Player.REPEAT_MODE_ONE : m == 2 ? Player.REPEAT_MODE_ALL : Player.REPEAT_MODE_OFF);
            c.resolve();
        });
    }

    @PluginMethod
    public void setShuffle(PluginCall c) {
        boolean e = c.getBoolean("enabled", false);
        onMain(c, () -> { PlayerHolder.player.setShuffleModeEnabled(e); c.resolve(); });
    }

    @PluginMethod
    public void setVolume(PluginCall c) {
        float v = c.getFloat("volume", 1f);
        onMain(c, () -> { PlayerHolder.player.setVolume(v); c.resolve(); });
    }
}

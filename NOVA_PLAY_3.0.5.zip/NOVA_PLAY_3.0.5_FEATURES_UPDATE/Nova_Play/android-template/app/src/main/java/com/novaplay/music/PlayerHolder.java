package com.novaplay.music;

import android.content.Context;
import android.media.AudioManager;
import android.media.audiofx.Equalizer;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;

final class PlayerHolder {
    static ExoPlayer player;
    static MediaSession session;
    static int audioSessionId;
    static Equalizer equalizer;

    // Must be called on the main thread.
    static synchronized void init(Context context) {
        if (player != null) return;
        Context app = context.getApplicationContext();
        AudioManager audioManager = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
        audioSessionId = audioManager != null ? audioManager.generateAudioSessionId() : 0;
        player = new ExoPlayer.Builder(app)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(), true)
            .build();
        if (audioSessionId > 0) player.setAudioSessionId(audioSessionId);
        session = new MediaSession.Builder(app, player).build();
    }
}
